import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * CasualParty class
 * Casual party allows a what-to-bring list that both guests and the host can access
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public class CasualParty extends Party implements Potluck {

	private Map<Item, Integer> potluckList;

	public CasualParty(String name, String dateAndTime, String address, String description, Host host) {
		super(name, dateAndTime, address, description, host);
		this.potluckList = new HashMap<>();
	}

	public CasualParty(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList, Map<Item, Integer> potluckList) {
		super(name, dateAndTime, address, description, host, guestList);
		this.potluckList = potluckList;
	}


	/**
	 * @return the potluckList
	 */
	public Map<Item, Integer> getPotluckList() {
		return potluckList;
	}

	/**
	 * @param potluckList the potluckList to set
	 */
	public void setPotluckList(Map<Item, Integer> potluckList) {
		this.potluckList = potluckList;
	}

	public void addItemToList(Item i, int qty) {
		potluckList.put(i, qty);
	}
	
	public void removeItem(Item i, int qty) {
		potluckList.remove(i, qty);
	}

	
	public Integer getNumItems() {
		return potluckList.size();
	}
	
	@Override
	public String potluckToString() {
		String s = "What-To-Bring List\n";
		for(Entry<Item, Integer> pair:  potluckList.entrySet()) { //iterate or LOOP through all the pairs
			s += pair.getValue() + " of " + pair.getKey() + "\n";
		}
		
		if(potluckList.isEmpty()) {
			s += "EMPTY\n";
		}
		return s;
	}
	
	public Integer getRemaining(String name) {
		Item i = findItem(name);
		Integer qty = 0;
		if(i != null) {
			qty = potluckList.get(i);
		}
		return qty;
	}
	
	public Item findItem(String name) {
		Item found = null;
		Iterator<Item> items = potluckList.keySet().iterator();
		while(items.hasNext()) {
			Item i = items.next();
			if(i.getName().equalsIgnoreCase(name)) {
				found = i;
			}
		}
		return found;
	}
	
	public void removeItemFromList(String name, Integer qty) {
		Iterator<Item> items = potluckList.keySet().iterator();
		while(items.hasNext()) {
			Item i = items.next();
			if(i.getName().equalsIgnoreCase(name)) {
				removeItem(i, qty);
				Integer num = potluckList.get(i) - qty;
				potluckList.put(i, num);
			}
		}
	}
	
	public void emptyList() {
		potluckList.clear();
	}


}
