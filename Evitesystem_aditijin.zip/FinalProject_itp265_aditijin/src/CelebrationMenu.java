/**
 * Prints out the menu options if hosting a celebration party
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public enum CelebrationMenu {
	VIEW_GUESTS("View Guest List"),
	ADD_GUESTS("Add guests"),
	REMOVE_GUEST("Remove a guest"),
	CLEAR_GUEST("Clear your guest list"),
	VIEW_GIFTS("View gift list"),
	QUIT("Go back to main menu");
	
	private String description;
	private CelebrationMenu(String description){
		this.description = description;
	}

	public String getDisplayString(){
		return this.description;
	}
	public static int getNumOptions() {
		return CelebrationMenu.values().length;
	}
	
	public static CelebrationMenu getOption(int num) {
		return CelebrationMenu.values()[num];
	}
	public static String getMenuOptions() {
		String prompt = "*****\tCelebration Party Host Menu\t*****";

		for(CelebrationMenu m : CelebrationMenu.values()){ //array from the enum
			prompt += "\n" + (m.ordinal() + 1) + ": " + m.getDisplayString();
		}
		prompt+="\n**********************************************\n";
		return prompt;
	}
}