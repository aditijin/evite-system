/**
 * RSVP enum
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public enum RSVP {
	YES("Yes"),
	MAYBE("Maybe"),
	NO("No"),
	UNKNOWN("Don't know yet");
	
	private String description;
	private RSVP(String description){
		this.description = description;
	}
	
	public String getDisplayString(){
		return this.description;
	}
	public static int getNumOptions() {
		return RSVP.values().length;
	}
	
	public static RSVP getOption(int num) {
		return RSVP.values()[num];
	}
	public static String getMenuOptions() {
		String prompt = "*****\tRSVP\t*****";

		for(RSVP m : RSVP.values()){ //array from the enum
			prompt += "\n" + (m.ordinal() + 1) + ": " + m.getDisplayString();
		}
		prompt+="\n";
		return prompt;
	}
}

