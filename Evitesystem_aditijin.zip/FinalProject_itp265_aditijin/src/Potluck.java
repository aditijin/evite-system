/**
 * Potluck interface
 * Only CasualParty implements this
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public interface Potluck {
	public String potluckToString();
}
