import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Party abstract class
 * Defines a party and common characteristics among the different types of parties
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */


public abstract class Party {
	private String name; // event title
	private String dateAndTime; 
	private String address; // event location
	private String description; // event descripion
	private Host host; // party host
	private Guest guest; // guest
	private Map<Guest, RSVP> guestList; // map of guests

	public Party(String name, String dateAndTime, String description, Host host) {
		this.name = name;
		this.dateAndTime = dateAndTime;
		this.description = description;
		this.host = host;
		this.guestList = new HashMap<>();
	}

	public Party(String name, String dateAndTime, String address, String description, Host host) {
		this.name = name;
		this.dateAndTime = dateAndTime;
		this.address = address;
		this.description = description;
		this.host = host;
		this.guestList = new HashMap<>();
	}

	public Party(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList) {
		this.name = name;
		this.dateAndTime = dateAndTime;
		this.address = address;
		this.description = description;
		this.host = host;
		this.guestList = guestList;
	}
	
	public Party(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList, Guest guest) {
		this.name = name;
		this.dateAndTime = dateAndTime;
		this.address = address;
		this.description = description;
		this.host = host;
		this.guestList = guestList;
		this.guest = guest;
	}

	/**
	 * @return the guest
	 */
	public Guest getGuest() {
		return guest;
	}

	/**
	 * @param guest the guest to set
	 */
	public void setGuest(Guest guest) {
		this.guest = guest;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the dateAndTime
	 */
	public String getDateAndTime() {
		return dateAndTime;
	}

	/**
	 * @param dateAndTime the dateAndTime to set
	 */
	public void setDateAndTime(String dateAndTime) {
		this.dateAndTime = dateAndTime;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the host
	 */
	public User getHost() {
		return host;
	}

	/**
	 * @param host the host to set
	 */
	public void setHost(Host host) {
		this.host = host;
	}

	/**
	 * @return the guestList
	 */
	public Map<Guest, RSVP> getGuestList() {
		return guestList;
	}

	/**
	 * @param guestList the guestList to set
	 */
	public void setGuestList(Map<Guest, RSVP> guestList) {
		this.guestList = guestList;
	}

	//	will add a guest to the guest list
	public void addGuestToList(Guest g) {
		//		default quantity is 1
		guestList.put(g, RSVP.UNKNOWN);
		g.addParty(this);
	}

	// will remove a guest from the guest list
	public void removeGuest(Guest g) {
		guestList.remove(g);
	}
	
	public void updateRSVP(Guest g, RSVP status) {
		guestList.put(g, status);
	}


	public String guestListToString() {
		String guestString = name + "'s Guest List\n";

		for(Entry<Guest, RSVP> pair:  guestList.entrySet()) { //iterate or LOOP through all the pairs
			guestString += pair.getKey() + ", RSVP: " + pair.getValue() + "\n";
		}

		if(guestList.isEmpty()) {
			guestString += "EMPTY\n";
		}
		return guestString;
	}

	public void emptyList() {
		guestList.clear();
	}

	@Override
	public String toString() {
		return name + "\n" + "Hosted by: " + host.getName() + "\n" + dateAndTime + "\n" + address;
	}
	
	public void removeGuest(String name) {
		Iterator<Guest> guests = guestList.keySet().iterator();
		while(guests.hasNext()) {
			Guest g = guests.next();
			if(g.getName().equalsIgnoreCase(name)) {
				removeGuest(g);
			}
		}
	}
	
	
	public Guest findGuest(String name) {
		Guest found = null;
		Iterator<Guest> guests = guestList.keySet().iterator();
		while(guests.hasNext()) {
			Guest g = guests.next();
			if(g.getName().equalsIgnoreCase(name)) {
				found = g;
			}
		}
		return found;
	}

}
