/**
 * Gift list interface
 * Only CelebrationParty implements this
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public interface GiftList {
	public String giftListToString();
	
}
