import java.util.ArrayList;
import java.util.Map;

/**
 * CelebrationParty class
 * Allows a gift list that the guest can contribute to but the host can only view
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */

public class CelebrationParty extends Party implements GiftList {

	private Gift gift;
	private ArrayList<Gift> giftList;

	public CelebrationParty(String name, String dateAndTime, String address, String description, Host host) {
		super(name, dateAndTime, address, description, host);
		this.giftList = new ArrayList<>();
	}

	public CelebrationParty(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList, Gift gift) {
		super(name, dateAndTime, address, description, host, guestList);
		this.gift = gift;
	}

	public CelebrationParty(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList, Gift gift, ArrayList<Gift> giftList) {
		super(name, dateAndTime, address, description, host, guestList);
		this.gift = gift;
		this.giftList = giftList;
	}


	/**
	 * @return the gift
	 */
	public Gift getGift() {
		return gift;
	}

	/**
	 * @param gift the gift to set
	 */
	public void setGift(Gift gift) {
		this.gift = gift;
	}

	/**
	 * @return the giftList
	 */
	public ArrayList<Gift> getGiftList() {
		return giftList;
	}

	/**
	 * @param giftList the giftList to set
	 */
	public void setGiftList(ArrayList<Gift> giftList) {
		this.giftList = giftList;
	}


	public void addGift(Gift g) {
		giftList.add(g);
	}

	@Override
	public String giftListToString() {
		String s = "Gift List\n";

		if(giftList.size() == 0) {
			s += "No gifts added yet.\n";
		}
		else {
			for(int i = 0; i < giftList.size(); i++) {
				s += (i+1) + ".) " + giftList.get(i) + "\n";
			}
		}
		return s;
	}
}