/**
 * MusicGenre enum
 * Was supposed to define the genres of music (not implemented)
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 */

public enum MusicGenre {
	POP,
	HIP_HOP,
	EDM,
	RNB,
	JAZZ,
}
