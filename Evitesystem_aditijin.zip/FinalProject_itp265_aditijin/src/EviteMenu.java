/**
 * Prints out the main menu options in EviteSystem
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public enum EviteMenu {
	LOG_IN("Log in or create an account"),
	LOG_OUT("Log out current user"),
	VIEW_HOSTING("View parties you're hosting"),
	VIEW_INVITED("View parties you're invited to"),
	CREATE_PARTY("Create an invitation for a new party"),
	UPGRADE("Upgrade to a Premium account"),
	DISPLAY_PREMIUM("View and select Premium Features (Premium Users Only)"),
	SAMPLE_RUN("View a sample run of data"),
	QUIT("Quit");
	
	private String description;
	private EviteMenu(String description){
		this.description = description;
	}

	public String getDisplayString(){
		return this.description;
	}
	public static int getNumOptions() {
		return EviteMenu.values().length;
	}
	
	public static EviteMenu getOption(int num) {
		return EviteMenu.values()[num];
	}
	public static String getMenuOptions() {
		String prompt = "*****\tEvite Main Menu\t*****";

		for(EviteMenu m : EviteMenu.values()){ //array from the enum
			prompt += "\n" + (m.ordinal() + 1) + ": " + m.getDisplayString();
		}
		prompt+="\n**********************************************\n";
		return prompt;
	}
}