/**
 * Abstract User Class
 * Is used for login
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public abstract class User {
	private String name;
	private String email;
	private String password;
	private boolean isPremium;


	public User(String name, String email) {
		this.name = name;
		this.email = email;
	}

	public User(String name, String email, String password) {
		this.name = name;
		this.email = email;
		this.password = password;
	}


	public User(String name, String email, String password, boolean isPremium) {
		this.name = name;
		this.email = email;
		this.password = password;
		this.isPremium = isPremium;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the isPremium
	 */
	public boolean isPremium() {
		return isPremium;
	}

	/**
	 * @param isPremium the isPremium to set
	 */
	public void setPremium(boolean isPremium) {
		this.isPremium = isPremium;
	}
	
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public boolean changePassword(String oldPassWord, String newPassWord) {
		boolean changed = false;
		if(verifyPassword(oldPassWord)) {
			this.password = newPassWord;
			changed = true;
		}
		return changed;	
	}

	public boolean verifyPassword(String pass) {
		// TODO Auto-generated method stub
		return password.equals(pass);
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + ": " + name + ", email = " + email;
	}

	//upgrade the user from free to premium account
	public void upgrade() {
		if(! (isPremium)) {
			isPremium = true;
		}
	}
	
	public String toFileString() {
		String fileLine = getName() + "/" + getEmail() + "/" + password + "/";
		if(isPremium()) {
			fileLine += "host";
		}
		else {
			fileLine += "guest";
		}
		return fileLine;
	}

}
