/**
 * Prints out the premium menu options 
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */

public enum PremiumMenu {
	DISPLAY_MUSIC("Choose from songs to add to your own custom party playlist"), // did not have time to implement this
	QUIT("Go back to Main Menu");
	
	private String description;
	private PremiumMenu(String description){
		this.description = description;
	}
	
	public String getDisplayString(){
		return this.description;
	}
	public static int getNumOptions() {
		return PremiumMenu.values().length;
	}
	
	public static PremiumMenu getOption(int num) {
		return PremiumMenu.values()[num];
	}
	public static String getMenuOptions() {
		String prompt = "*****\tPremium Member Menu\t*****";

		for(PremiumMenu m : PremiumMenu.values()){ //array from the enum
			prompt += "\n" + (m.ordinal() + 1) + ": " + m.getDisplayString();
		}
		prompt+="\n**********************************************\n";
		return prompt;
	}
}
