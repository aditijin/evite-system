import java.util.ArrayList;

/**
 * Host class
 * Subclass of Guest, is premium
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public class Host extends Guest {

	private ArrayList<Party> partiesHosting;
	
	
	public Host(String name, String email, String password) {
		super(name, email, password, true);
		this.partiesHosting = new ArrayList<>();
	}
	
	public Host(String name, String email, String password, ArrayList<Party> invitedParties) {
		this(name, email, password, invitedParties, new ArrayList<>());
	}
	
	public Host(String name, String email, String password, ArrayList<Party> invitedParties, ArrayList<Party> partiesHosting) {
		super(name, email, password, true, invitedParties);
		this.partiesHosting = partiesHosting;
	}
	
	/**
	 * @return the partiesHosting
	 */
	public ArrayList<Party> getPartiesHosting() {
		return partiesHosting;
	}

	/**
	 * @param partiesHosting the partiesHosting to set
	 */
	public void setPartiesHosting(ArrayList<Party> partiesHosting) {
		this.partiesHosting = partiesHosting;
	}

	public void addPartyToList(Party p) {
		partiesHosting.add(p);
	}

	public String PartiesHostingToString() {
		String s = "Parties Hosted By " + getName() + ":\n";
		
		if(partiesHosting.size() == 0) {
			s += "No parties added yet.\n";
		}
		else {
			for(int i = 0; i < partiesHosting.size(); i++) {
				s += "\n" + (i+1) + ".) " + partiesHosting.get(i) + "\n";
			}
		}
		return s;
	}
	
}
