import java.util.Map;

/**
 * VirtualParty class
 * Has a link that the host is supposed to copy paste from Zoom
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */

public class VirtualParty extends Party {

	private String link;

	public VirtualParty(String name, String dateAndTime, String description, Host host, String link) {
		super(name, dateAndTime, description, host);
		this.link = link;
	}
	
	public VirtualParty(String name, String dateAndTime, String address, String description, Host host, Map<Guest, RSVP> guestList, String link) {
		super(name, dateAndTime, address, description, host, guestList);
		this.link = link;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}
	
	public String linkToString() {
		return "Your Zoom Party Link: " + link;
	}
	
	@Override
	public String toString() {
		return getName() + "\n" + "Hosted by: " + getHost().getName() + "\n" + getDateAndTime() + "\n" + link;
	}
}
