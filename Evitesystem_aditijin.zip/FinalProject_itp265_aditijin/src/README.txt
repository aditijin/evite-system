Design Document

Final Project Checkpoint 1:
- Implemented peer review feedback as well as feedback from Kendra during office hours and changed my Host class to extend from Guest instead of User.
- Decided to keep User and Party as abstract classes.
- Included the string address in the Party class rather than the Host class to represent the location of a party.
- Also, initially recorded the parties the Guest was invited to as well as the parties the host was throwing in maps, but changed them to arrays instead.
- Created a "Themed" interface that other party sub-classes would implement.
- Rather than including parties like Birthday and Wedding in an enum, I decided to make separate classes from them to improve the hierarchy.
- Split PartyMenu into HostMenu and GuestMenu (will use the latter if it's required later).

Final Project Checkpoint 2:
- Implemented a MusicGenre and Music class and will include a file with a list of songs that the host can add to their music playlist
- Added songs to a songs.csv file
- Have an option to re-send the invitation to those who have not RSVP'd
- What to bring list
- (Premium) add your own premium logo
- (Premium) ??? allow the invitation to pop up using JOptionPane (and display the logo if they selected one)
- Will have a hasGiftList interface
- Keep track of all gifts (name of gift and gift giver)
- Made EviteSystem and EviteMenu functional so that it prints out the main menu
- Login functionality works

After Checkpoint 2:
- Will use two subclasses from Party (celebration vs casual (ones that don't have gifts, bring your own food (potluck)
- Typecasting from Host to User wasn't working, and I didn't want to make User an abstract class,
so I decided to add all of Host's functionalities to User and instead of having a class, have a isHost boolean in the User class.
-(for the above) did two versions, one in which the Host and Guest class are used and another in which only the User class is used.
- The one that I have submitted has the Host and Guest classes, but some functionalities don't work in Evite System as of now.
- Considered enabling donations for parties, but decided against it.
- Still have to write to a file and complete main menu methods.
- Had a separate menu in which the host could add songs to a playlist, but left it for a v2 version as I didn't have time to implement it.
- All hosts are premium users and all guests are free users, did not have the time to implement the ideas I had above for premium
- Implemented a what-to-bring list for casual parties and a gift list for celebration parties
- Removed aforementioned "Themed" interface
- Also, users.txt is in the project on the PC, but I had to remove it from the Eclipse folder because it kept creating errors when trying 
to run EviteSystem.

