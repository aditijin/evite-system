/**
 * Prints out the menu options if hosting a casual party
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public enum CasualMenu {
	VIEW_GUESTS("View Guest List"),
	ADD_GUESTS("Add guests"),
	REMOVE_GUEST("Remove a guest"),
	CLEAR_GUEST("Clear your guest list"),
	VIEW_POTLUCK("View what-to-bring list"),
	ADD_ITEM("Add item to what-to-bring list"),
	REMOVE_ITEM("Remove item from what-to-bring list"),
	QUIT("Go back to main menu");
	
	private String description;
	private CasualMenu(String description){
		this.description = description;
	}

	public String getDisplayString(){
		return this.description;
	}
	public static int getNumOptions() {
		return CasualMenu.values().length;
	}
	
	public static CasualMenu getOption(int num) {
		return CasualMenu.values()[num];
	}
	public static String getMenuOptions() {
		String prompt = "*****\tCasual Party Host Menu\t*****";

		for(CasualMenu m : CasualMenu.values()){ //array from the enum
			prompt += "\n" + (m.ordinal() + 1) + ": " + m.getDisplayString();
		}
		prompt+="\n**********************************************\n";
		return prompt;
	}
}