/**
 * Music class
 * Is supposed to represent songs in a playlist (was not implemented)
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 */

public class Music {
	private MusicGenre musicgenre;
	private String name;
	private String artist;
	private String releaseYear;
	
	public Music(String name, String artist, String releaseYear, MusicGenre musicgenre) {
		this.name = name;
		this.artist = artist;
		this.releaseYear = releaseYear;
		this.musicgenre = musicgenre;
	}
	
	/**
	 * @return the musicgenre
	 */
	public MusicGenre getMusicgenre() {
		return musicgenre;
	}

	/**
	 * @param musicgenre the musicgenre to set
	 */
	public void setMusicgenre(MusicGenre musicgenre) {
		this.musicgenre = musicgenre;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the artist
	 */
	public String getArtist() {
		return artist;
	}

	/**
	 * @param artist the artist to set
	 */
	public void setArtist(String artist) {
		this.artist = artist;
	}

	/**
	 * @return the releaseYear
	 */
	public String getReleaseYear() {
		return releaseYear;
	}

	/**
	 * @param releaseYear the releaseYear to set
	 */
	public void setReleaseYear(String releaseYear) {
		this.releaseYear = releaseYear;
	}

	@Override
	public String toString() {
		return getName() + " by " + getArtist() + ", genre: " + musicgenre;
	}
}
