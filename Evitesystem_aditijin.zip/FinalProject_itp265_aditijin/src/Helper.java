import java.io.Reader;
import java.util.Scanner;

/**
 * Helper is a utility class for ITP 265 that helps provide a friendly way to read input from
 * a user and verify that the input is correct. 
 * 
 * Helper exists to encapsulate using the Scanner to get input from the
 * console window. It will handle simple error checking to ensure correct
 * data type and in some cases, values in the "right" range
 * 
 * To use this class, create an instance and call the desired methods:
 * 
 * Helper help = new Helper();
 * String input = help.inputLine("What is your full name?");
 * String word = help.inputWord("What is your birth month?");
 * String beverage = help.inputWord("Would you like coffee or tea?", "coffee", "tea");
 * int num = help.inputInt("Please enter an integer number");
 * int restrictedInt = help.inputInt("Please enter a number 1-10>", 1, 10);
 * double dub = help.inputDouble("Enter a floating point number>");
 * boolean value = help.inputBoolean("You like learning. Type \"true\" or \"false\"");
 * boolean val2 = help.inputYesNo("Do you like chocolate? (y/n)>"); 
 * help.printPretty("ITP 265 is fun");
 * 
 * @author Kendra Walther, Aditi Jindal
 * ITP 265, Summer 2020 
 * Utility code
 */
public class Helper {
	private Scanner myScanner;

	/**
	 * Constructor sets up a Scanner to be used by the class in order to read input from the standard console window (System.in)
	 */
	public Helper() {
		myScanner = new Scanner(System.in);
	}

	/**
	 * Short-cut helper method that prints a String with a series of stars around it.
	 * @param output: The String to be printed
	 */
	public void printPretty(String output) {
		System.out.println("***********************************************************************************************");
		System.out.println(output);
		System.out.println("***********************************************************************************************");
	}


	/**
	 * Prompt the user and read a floating point number, clearing whitespace or the enter after the number
	 * @param prompt
	 * @param minValue
	 * @param maxValue
	 * @return: double value  in the correct range
	 */
	public double inputDouble(String prompt, double minValue, double maxValue) {
		// Remember: DRY: don't repeat code
		double value = inputDouble(prompt);
		while(value < minValue || value > maxValue) {
			System.out.println("Double needs to be in the range " + minValue + " - " + maxValue);
			value = inputDouble(prompt);
		}
		return value;
	}

	/**
	 * Prompt the user and read a floating point number, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: a double value 
	 */
	public double inputDouble(String prompt) {
		System.out.println(prompt);
		while (! myScanner.hasNextDouble()) { //tell scanner to look at console, and see if there is NOT a double
			String garbage = myScanner.nextLine(); // clear the pipe (input stream) of the non double
			System.out.println(garbage + " was not a double. please try again.\n");
			System.out.println(prompt);
		}
		double value = myScanner.nextDouble();

		// Just in case, clear the input stream (buffer) and get rid of the enter that is still there
		myScanner.nextLine();
		return value;
	}

	/**
	 * Prompt the user and read one line of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a line of user input (including spaces, until they hit enter)
	 */
	public String inputLine(String prompt) {
		System.out.println(prompt);
		String value = myScanner.nextLine();
		return value;
	}

	/**
	 * Prompt the user and read an int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int 
	 */
	public int inputInt(String prompt) { 

		System.out.println(prompt);
		while (! myScanner.hasNextInt()) { //tell scanner to look at console, and see if there is NOT a double
			String garbage = myScanner.nextLine(); // clear the pipe (input stream) of the non double
			System.out.println(garbage + " was not an int. please try again.\n");
			System.out.println(prompt);
		}
		int value = myScanner.nextInt();


		// Just in case, clear the input stream (buffer) and get rid of the enter that is still there
		myScanner.nextLine();
		return value;
	}

	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int between minValue and maxValue
	 */
	public int inputInt(String prompt, int min, int max) { 
		int value = inputInt(prompt);
		while(value < min || value > max) {
			System.out.println("Int needs to be in the range " + min + " - " + max);
			value = inputInt(prompt);
		}
		//myScanner.nextLine(); 
		return value;
	}

	// NEW METHOD - developed for LightsOutGame2D such that the user can input -1 to quit without it
	//resulting in an error
	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, clearing whitespace or the enter after the number
	 * Takes in a "quit value" such that inputting -1 does not result in an error
	 * @param prompt: the question to ask the user 
	 * @return: an int between minValue and maxValue, and one that does not equal the number used to quit
	 */
	public int inputInt(String prompt, int min, int max, int quit) { 
		int value = inputInt(prompt);
		if(value != quit) {
			while(value < min || value > max) {
				System.out.println("Int needs to be in the range " + min + " - " + max);
				value = inputInt(prompt);
			}
		}
		//myScanner.nextLine(); 
		return value;
	}

	/**
	 * Prompt the user and read a postive (>0) int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int > 0
	 */
	public int inputPositiveInt(String prompt) {
		//make sure no negative numbers
		int posInt = inputInt(prompt);
		while(!(posInt > 0)) {
			System.out.println("Please enter a positive int.");
			posInt = inputInt(prompt);
		}
		return posInt;
	}

	/**
	 * Prompt the user and read one word of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a one word String - if the user enters multiple words, all other input until the return will be discarded.
	 */
	public String inputWord(String prompt) { 
		//assume a one word answer (not a whole line of text)
		System.out.println(prompt);
		String value = myScanner.next(); //grabs one word

		// Just in case, clear the input stream (buffer) and get rid of the enter that is still there
		myScanner.nextLine(); // if the user typed extra words (and the enter key), clear those from the pipe
		return value;

	}

	//	NEW METHOD - developed for LightsOutGame 2D for the user to input a character (column letter)
	/**
	 * Prompt the user and read one letter of text as a Char
	 * @param prompt: the question to ask the user
	 * @ return: a Char - if the user enters any other char, all other input until the return will be discarded.
	 */
	public char inputChar(String prompt, int num) {
		System.out.println(prompt);
		String choice = myScanner.next();
		if (num == 3) {
			while (! ( choice.equalsIgnoreCase("a") || choice.equalsIgnoreCase("b") || choice.equalsIgnoreCase("c") ) ) {
				System.out.println("Invalid input, please try again. ");
				choice = myScanner.next();
				myScanner.nextLine();
			}
		}
		else if(num == 4) {
			while (! ( choice.equalsIgnoreCase("a") || choice.equalsIgnoreCase("b") || choice.equalsIgnoreCase("c") ||
					choice.equalsIgnoreCase("d") ) ) {
				System.out.println("Invalid input, please try again. ");
				choice = myScanner.next();
				myScanner.nextLine();
			}
		}
		else if(num == 5) {
			while (! ( choice.equalsIgnoreCase("a") || choice.equalsIgnoreCase("b") || choice.equalsIgnoreCase("c") ||
					choice.equalsIgnoreCase("d") || choice.equalsIgnoreCase("e") ) ) {
				System.out.println("Invalid input, please try again. ");
				choice = myScanner.next();
				myScanner.nextLine();
			}
		}
		
		return choice.charAt(0);
				
	}
		


/**
 * Prompt the user and read a boolean value, clearing whitespace or the enter after the number
 * @param prompt: the question to ask the user 
 * @return: a boolean value 
 */
public boolean inputBoolean(String prompt) { 
	//use scanner's nextBoolean method, and/or hasNextBoolean() method
	System.out.println(prompt);
	while (! myScanner.hasNextBoolean()) { //tell scanner to look at console, and see if there is NOT a boolean
		String garbage = myScanner.nextLine(); // clear the pipe (input stream) of the non double
		System.out.println(garbage + " was not a boolean. please try again.\n");
		System.out.println(prompt);
	}
	boolean value = myScanner.nextBoolean();

	// Just in case, clear the input stream (buffer) and get rid of the enter that is still there
	myScanner.nextLine();
	return value;
}

/**
 * Prompt the user enter yes or no (will match y/yes and n/no any case) and return true for yes and false for no.
 * @param prompt: the question to ask the user 
 * @return: a boolean value 
 */
public boolean inputYesNo(String prompt) {
	String choice = "moist";
	while (! (  choice.equalsIgnoreCase("yes") || choice.equalsIgnoreCase("y")
			|| choice.equalsIgnoreCase("no") || choice.equalsIgnoreCase("n") ) ){
		System.out.println(prompt);
		choice = myScanner.next();
		myScanner.nextLine();
	}
	if (choice.equalsIgnoreCase("yes") || choice.equalsIgnoreCase("y")) {
		return true;
	}
	return false;
}
/**
 * Prompt the user and read one word - which must match either option1 or option2 parameters.
 * @param prompt: the question to ask the user (should include the two valid options the user should choose from)
 * @param option1 : One string option for the user to choose.
 * @param option2: the other string option for the user to choose.
 * @return: A string matching either option1 or option2
 */
public String inputWord(String prompt, String option1, String option2) { 
	System.out.println(prompt);
	String value = myScanner.next();
	while(!(value.equalsIgnoreCase(option1) || value.equalsIgnoreCase(option2))) {
		System.out.println("Word needs to be one of the choices " + option1 + " or " + option2);
		value = myScanner.next();
	}
	myScanner.nextLine(); 
	return value; 
}

//developed for final project
/**
 * Prompt the user and read one word - which must match either option1, option2, or option3 parameters.
 * @param prompt: the question to ask the user (should include the three valid options the user should choose from)
 * @param option1 : the first string option for the user to choose.
 * @param option2: the second string option for the user to choose.
 * @param option2: the third string option for the user to choose.
 * @return: A string matching either option1, option2, or option3
 */
public String inputWord(String prompt, String option1, String option2, String option3) { 
	System.out.println(prompt);
	String value = myScanner.next();
	while(!(value.equalsIgnoreCase(option1) || value.equalsIgnoreCase(option2) || value.equalsIgnoreCase(option3))) {
		System.out.println("Word needs to be one of the choices " + option1 + ", " + option2 + ", or " + option3);
		value = myScanner.next();
	}
	myScanner.nextLine(); 
	return value; 
}

}