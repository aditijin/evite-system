import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


/**
 * EviteSystem class
 * 
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public class EviteSystem {
	private Map<String, User> users;
	private User currentUser; // who is logged in
	private Helper helper;

	public EviteSystem() {
		helper = new Helper();
		users = new HashMap<>();
		currentUser = null;
		//if we have existing users saved, read them in now.
		readExistingUsersFromFile("bin/users.txt");
		System.out.println(usersToString()); // prints out the current map of users
	}

	public void run() {
		boolean done = false;
		while(!done) {
			if(currentUser == null) {}
			else {
				String s = "* " + currentUser.getName();
				if(currentUser.isPremium()) {
					s += " (Premium Member)";
				}
				s += " is logged in *";
				System.out.println(s);
			}

			String menu = EviteMenu.getMenuOptions();
			int input = helper.inputInt(menu, 1, EviteMenu.getNumOptions());
			EviteMenu menuItem = EviteMenu.getOption(input - 1);
			switch(menuItem) {
			case LOG_IN:
				signin(); // make a user
				break;
			case LOG_OUT:
				logout();
				break;
			case VIEW_HOSTING:
				viewHosting();
				break;
			case VIEW_INVITED: 
				viewInvited();
				break;
			case CREATE_PARTY: 
				createParty();
				break;
			case UPGRADE:
				upgradeUser();
				break;
			case DISPLAY_PREMIUM:
				displayPremium();
				break;
			case SAMPLE_RUN:
				makeFakeData(); // view this method for the sample log in credentials
				break;
			case QUIT: // writes the users to the file
				done = true;
				break;
			} //end switch

			//Pause before continuing.
			if(!done) helper.inputLine("Hit any key to continue");
		}// done loop
		System.out.println("Thank you for using Evite!");
	}


	//	This method will allow the user to view a list of parties they are invited to.
	//	From there, they can select a party from that list and choose whether they want to RSVP
	//	now or later. Depending on the type of party (celebration or potluck), they can send a
	//	gift or type in the item they're going to bring.
	private void viewInvited() {
		User u = getUser();
		Guest g = (Guest) u;
		System.out.println(g.InvitedPartiesToString());
		if(! (g.getInvitedParties().size() == 0)) {
			boolean select = helper.inputYesNo("Would you like to select a party? (y/n)");
			if(select) {
				int i = helper.inputInt("Select a party: ", 1, g.getInvitedParties().size());
				Party p = g.getInvitedParties().get(i-1);
				if(p.getGuestList().get(g) == RSVP.UNKNOWN) {
					boolean r = helper.inputYesNo("Do you want to RSVP to this party? (y/n) ");
					if(r) {
						rsvp(p, g);
					}
				}
				if(p instanceof CasualParty) {
					boolean view = helper.inputYesNo("Would you like to view the what-to-bring list for this party? (y/n)");
					if(view) {
						casualPartyGuest(p);
					}
				}
				else if (p instanceof CelebrationParty) {
					celebrationPartyGuest(p);
				}
			}
		}
	}

	//this method is called when a user selects a celebration party they are invited to, and allows them to gift something
	private void celebrationPartyGuest(Party p) {
		CelebrationParty party = (CelebrationParty) p;
		System.out.println(party.giftListToString());
		boolean give = helper.inputYesNo("Would you like to gift something? (y/n)");
		if(give) {
			String name = helper.inputLine("Please enter the name of the gift.");
			String type = helper.inputLine("Please enter the type of gift (jewelry, clothes, toys, etc.)");
			Gift gift = new Gift(currentUser.getName(), name, type);
			party.addGift(gift);
		}
	}

	//this method is called when a user selects a casual party they are invited to, and allows them to bring something on 
	//the what-to-bring list
	private void casualPartyGuest(Party p){
		CasualParty party = (CasualParty) p;
		System.out.println(party.potluckToString());
		boolean bring = helper.inputYesNo("Would you like to bring an item on the what-to-bring list? (y/n)");
		if(bring) {
			removeItem(party);
		}
	}


	//prints out the RSVP menu if the user chooses to RSVP to a party
	private void rsvp(Party p, Guest g) {
		String menu = RSVP.getMenuOptions();
		int input = helper.inputInt(menu, 1, RSVP.getNumOptions());
		RSVP rsvp = RSVP.getOption(input - 1);
		switch(rsvp) {
		case YES:
			p.updateRSVP(g, RSVP.YES);
			break;
		case MAYBE: 
			p.updateRSVP(g, RSVP.MAYBE);
			break;
		case NO:
			p.updateRSVP(g, RSVP.NO);
			break;	
		case UNKNOWN:
			break;
		} //end switch
	}

	//	This method will allow the user to create a new invitation. It will require them to 
	//	enter in the event details and names of their guests to add to a guest list.
	private void createParty() {
		User u = getUser();
		getPremiumUser(u);
		if(u instanceof Host) {
			Host h = (Host) u;
			System.out.println("Please enter event details below.");
			String name = helper.inputLine("Event name: ");
			String description = helper.inputLine("Event description: ");
			String address = helper.inputLine("Event location (if in-person party) ");
			String dateAndTime = helper.inputLine("Event date and time: ");
			String partyType = helper.inputWord("Please type \"celebration\" for birthdays, wedding parties, etc, \"casual\" for \n"
					+ "potlucks, get-togethers, etc., or \"virtual\" for a safe Zoom party", "celebration", "casual", "virtual");

			Party p = null;
			if(partyType.equalsIgnoreCase("celebration")) {
				p = new CelebrationParty(name, dateAndTime, address, description, h);
			}
			else if (partyType.equalsIgnoreCase("casual")) {
				p = new CasualParty(name, dateAndTime, address, description, h);
			}
			else {
				String link = helper.inputLine("Please enter the Zoom link for your virtual party.");
				p = new VirtualParty(name, dateAndTime, description, h, link);
			}
			h.addPartyToList(p);
			printInvitation(p); 
			boolean guest = helper.inputYesNo("Would you like to add to your guest list at this time? (y/n)");
			if(guest) {
				addGuests(p);
			}
		}
	}

	// prints invitation differently for virtual parties
	private void printInvitation(Party p) {
		if(p instanceof VirtualParty) {
			VirtualParty v = (VirtualParty) p;
			helper.printPretty(v.toString());
		}
		else {
			helper.printPretty(p.toString());
		}
	}

	//this method is called when the host chooses to view a list of parties they are hosting
	//allows them to view guest list and add/remove guests as well as additional functionalities based on the party type
	private void viewHosting() {
		User u = getUser();
		getPremiumUser(u);
		if(u instanceof Host) {
			Host h = (Host) u;
			System.out.println(h.PartiesHostingToString());
			if(! (h.getPartiesHosting().size() == 0)) {
				boolean view = helper.inputYesNo("Do you want to view details of a party you're hosting? (y/n) ");
				if(view) {
					int i = helper.inputInt("Select a party: ", 1, h.getPartiesHosting().size());
					Party p = h.getPartiesHosting().get(i-1);
					partyHostMenu(p);
				}
			}	
		}
	}

	//returns the menu methods based on the party type
	private void partyHostMenu(Party p) {
		if(p instanceof CasualParty) {
			casualPartyHostMenu(p);
		}
		else if (p instanceof CelebrationParty) {
			celebrationPartyHostMenu(p);
		}

		else if (p instanceof VirtualParty) {
			virtualPartyHostMenu(p);
		}
	}

	//menu displayed to the host if they view a celebration party from their list
	private void virtualPartyHostMenu(Party p) {
		VirtualParty virtual = (VirtualParty) p;
		boolean done = false;
		while(!done) {
			String menu = VirtualMenu.getMenuOptions();
			int input = helper.inputInt(menu, 1, VirtualMenu.getNumOptions());
			VirtualMenu menuItem = VirtualMenu.getOption(input - 1);
			switch(menuItem) {
			case VIEW_GUESTS:
				System.out.println(p.guestListToString());
				break;
			case ADD_GUESTS:
				addGuests(p);
				break;
			case REMOVE_GUEST:
				removeGuest(p);
				break;
			case CLEAR_GUEST:
				emptyList(p);
				break;
			case VIEW_LINK:
				System.out.println(virtual.linkToString() + "\n");
				break;
			case QUIT: 
				done = true;
				break;
			} //end switch
			if(!done) helper.inputLine("Hit any key to continue");
		}// done loop
		run(); // go back to main menu
	}


	//menu displayed to the host if they view a celebration party from their list
	private void celebrationPartyHostMenu(Party p) {
		CelebrationParty celebration = (CelebrationParty) p;
		boolean done = false;
		while(!done) {
			String menu = CelebrationMenu.getMenuOptions();
			int input = helper.inputInt(menu, 1, CelebrationMenu.getNumOptions());
			CelebrationMenu menuItem = CelebrationMenu.getOption(input - 1);
			switch(menuItem) {
			case VIEW_GUESTS:
				System.out.println(p.guestListToString());
				break;
			case ADD_GUESTS:
				addGuests(p);
				break;
			case REMOVE_GUEST:
				removeGuest(p);
				break;
			case CLEAR_GUEST:
				emptyList(p);
				break;
			case VIEW_GIFTS:
				System.out.println(celebration.giftListToString());
				break;
			case QUIT: 
				done = true;
				break;
			} //end switch
			if(!done) helper.inputLine("Hit any key to continue");
		}// done loop
		run(); // go back to main menu
	}


	//menu displayed to the host if they view a casual party from their list
	private void casualPartyHostMenu(Party p) {
		CasualParty casual = (CasualParty) p;
		boolean done = false;
		while(!done) {
			String menu = CasualMenu.getMenuOptions();
			int input = helper.inputInt(menu, 1, CasualMenu.getNumOptions());
			CasualMenu menuItem = CasualMenu.getOption(input - 1);
			switch(menuItem) {
			case VIEW_GUESTS:
				System.out.println(p.guestListToString());
				break;
			case ADD_GUESTS:
				addGuests(p);
				break;
			case REMOVE_GUEST:
				removeGuest(p);
				break;
			case CLEAR_GUEST:
				emptyList(p);
				break;
			case VIEW_POTLUCK:
				System.out.println(casual.potluckToString());
				break;
			case ADD_ITEM:
				addItem(casual);
				break;
			case REMOVE_ITEM:
				removeItem(casual);
				break;
			case QUIT: 
				done = true;
				break;
			} //end switch
			if(!done) helper.inputLine("Hit any key to continue");
		}// done loop
		run(); // go back to main menu
	}

	//this method is called when a host chooses to add guests to their party
	private void addGuests(Party p) {
		boolean done = false;
		while(! done) {
			String guestEmail = helper.inputLine("Please enter your guest's email: ");
			User g = users.get(guestEmail);
			if(g == null) {
				String guestName = helper.inputLine("Please enter the name of your guest: ");
				g = new Guest(guestName, guestEmail, "password");
				System.out.println("New guest added to party system. Password will be \"password\"");
				users.put(guestEmail, g);
			}
			else {
				System.out.println("Found registered user. Inviting " + g.getName() + " to your party.");
			}
			Guest guest = (Guest) g;
			p.addGuestToList(guest);
			boolean complete = helper.inputYesNo("Is your guest list complete? (y/n)");
			if(complete) {
				done = true;
			}
			if(!done) helper.inputLine("Hit any key to continue");
		}
	}

	//this method is called when a host chooses to remove a guest from their party	
	private void removeGuest(Party p) {
		String name = helper.inputLine("Please type in the name of the guest you want to remove: ");
		Guest g = p.findGuest(name);
		if(g == null) {
			System.out.println("No guest could be found.");
		}
		else {
			p.removeGuest(name);
			System.out.println(name + " was removed from your guest list.");
		}
	}

	//this method is called when a host chooses to clear their guest list
	private void emptyList(Party p) {
		p.emptyList();
		System.out.println("Your guest list has been cleared.");
	}

	//is called to add an item to the what-to-bring list for a casual party
	private void addItem(CasualParty p) {
		String name = helper.inputLine("Enter the name of the item you would like to add: ");
		String type = helper.inputLine("Enter the type of the item (drinks, food, utensils, etc.)");
		Item item = new Item(name, type);
		Integer qty = helper.inputInt("How many of this item would you like to add? (between 1 and 50)", 1, 50);
		p.addItemToList(item, qty);
	}

	//is called to remove an item from the what-to-bring list for a casual party
	private void removeItem(CasualParty p) {
		String name = helper.inputLine("Please enter the name of the item.");
		int needed = p.getRemaining(name);
		if(needed == 0) {
			System.out.println("No item found. Please check the spelling of your input or reference the list.");
		}
		else {
			Integer qty = helper.inputInt("Please enter the quantity of the item.", 0, needed);
			p.removeItemFromList(name, qty);
			System.out.println(p.potluckToString());
		}	
	}


	//displays the premium menu - didn't get to implement the music playlist
	private void displayPremium() {
		User u = getUser();
		getPremiumUser(u);

		boolean done = false;
		while(!done) {
			String menu = PremiumMenu.getMenuOptions();
			int input = helper.inputInt(menu, 1, PremiumMenu.getNumOptions());
			PremiumMenu menuItem = PremiumMenu.getOption(input - 1);
			switch(menuItem) {
			case DISPLAY_MUSIC:
				System.out.println("Available in v2");
				break;
			case QUIT: 
				done = true;
				break;
			} //end switch
			if(!done) helper.inputLine("Hit any key to continue");
		}// done loop
		run(); // go back to main menu
	}

	//is called to see if the user is a host - if not, it allows the user to upgrade
	private User getPremiumUser(User u) {
		if(! (u instanceof Host)) {
			boolean upgrade = helper.inputYesNo("This is a Premium feature. Would you like to upgrade to Premium? (y/n)");
			if(upgrade) {
				upgradeUser();
				u = currentUser;
			}
		}
		return u;
	}

	//is called to upgrade the user from free to premium
	private void upgradeUser() {
		User u = getUser();
		if(u.isPremium()) {
			System.out.println("You already have a Premium account.");
		}
		else {
			Guest g = (Guest) currentUser;
			boolean upgrade = helper.inputYesNo("Upgrading to Premium will cost $14.99. Confirm upgrade? (y/n)");
			if(upgrade) {
				currentUser.upgrade();
				currentUser = new Host(g.getName(), g.getEmail(), g.getPassword(), g.getInvitedParties());
				users.put(g.getEmail(), g);
			}
		}
	}

	//if user isn't logged in, this method is called to have the person log in or create an account
	private User getUser() {
		User u = currentUser;
		if(u == null) { // if the user is a guest
			System.out.println("Please sign in or create an account before continuing.");
			String email = helper.inputLine("Please enter your email address: ");
			if(users.containsKey(email)) {
				u = login(email);
			}
			else {
				u = createNewUser(email);
			}
		}
		return u;
	}

	//is called when the user chooses to log in or create an account
	private void signin() {
		//sets the CurrentUser variable to that User object that is made
		System.out.println("Would you like to sign in to your account or create a new account?");
		System.out.println("(If you're a new user that has been invited to a party, your default password is \"password\"");
		//TODO 
		//check if password is "password", suggest that the user should create their own password
		String choice = helper.inputWord("Type: \"signin\" or \"create\"", "signin", "create");
		if(choice.equalsIgnoreCase("signin")) {
			String email = helper.inputLine("Please enter your email address to sign in: ");
			if(! (users.containsKey(email))) {
				boolean option = helper.inputYesNo("Didn't find a user with that email. Would you like to create an account? (y/n)");
				if(option) {
					createNewUser(email);
				}
			}
			else {
				login(email);
			}
		}
		else {
			String email = helper.inputLine("Please enter your email address to create an account: "); 
			createNewUser(email);
		}
	}

	//is called when the user chooses to sign in to an existing account  
	public User login(String email) {
		User u  = users.get(email);
		if(u != null) {
			String pass = helper.inputLine("Please enter your password:");
			boolean correct = u.verifyPassword(pass);
			if(correct) {
				currentUser = u;
				return u;
			}
			else {
				System.out.println("ERROR: incorrect password for that user.");
				return null;
			}
		}
		return null;
	}

	//is called when the user chooses to create an account
	public User createNewUser(String email) {
		User u;
		if(users.containsKey(email)) {
			System.out.println("Can't create a user with this email, because they already exist in system. Please login instead");
			u =  login(email);
		}
		else {
			//GET THE DATA NEEDED TO MAKE THE USER
			String name = helper.inputLine ("Please enter your full name : "); 
			String password =  helper.inputLine("Please enter your password: "); 

			boolean premium = helper.inputYesNo("Would you like to update to Premium for $14.99 to be able to host parties? (y/n)");
			if(premium) { // if premium, user automatically becomes a host
				u = new Host(name, email, password);
			}
			else { // if free, user automatically becomes a guest
				u = new Guest(name, email, password);
			}
			users.put(email, u);// add the user to the map
		}
		currentUser = u;
		return u;
	}

	//logs the current user out of the system
	private void logout() {
		User u = currentUser;
		if(u != null) {
			System.out.println("Logged " + u.getName() + " out of Evite"); // was initially helper.print
			currentUser = null;
		}
	}

	//reads in the users that are already in the file
	private void readExistingUsersFromFile(String fileName) {
		try(FileInputStream fis = new FileInputStream(fileName);
				Scanner scan = new Scanner(fis))	{  
			while(scan.hasNextLine()) {
				String line = scan.nextLine(); // each line is a user in the system
				User user = parseLineToUser(line);
				//once we have a user, put it in map
				users.put(user.getEmail(), user); //unique email maps to ONE user in the system
			}
		} catch (IOException e) {
			System.out.println("Exception in readExistingUsersFromFile for " + fileName +
					"\nThis means the database of users will start off empty.");
		}

	}
	/**
	 * Takes a line from our file and turns it into a user object
	 * @param line (where everything is split by the "/" symbol)
	 * @return a User object
	 */
	private User parseLineToUser(String line) {
		User u;
		// line needs to be broken apart
		Scanner lineReader = new Scanner(line);
		lineReader.useDelimiter("/"); // instead of white space, use the / as the thing that breaks the line apart

		String name = lineReader.next();
		String email = lineReader.next(); 
		String password = lineReader.next(); 
		String guestOrHost = lineReader.next();

		if(guestOrHost.equals("guest")) {
			u = new Guest(name, email, password);
		}
		else {
			u = new Host(name, email, password);
		}
		return u;
	}

	//call to print the map of users
	public String usersToString() {
		// just a way to visualize the map of users
		// go through the map, get all the keys, and print all the User objects
		String s = "Map of All Users --> Email: User Object\n";
		for(String key: users.keySet()) { // for each key in the user map of keys....
			User value = users.get(key); // get the object associated with the key
			s += "\t" + key + ": "+ value + "\n";
		}
		return s;
	}

	//method to write the users to the file ("users.txt")
	private void writeUsersToFile(String fileName) {
		System.out.println("writing users to file method, using: " + fileName);
		try (FileOutputStream fos = new FileOutputStream(fileName);
				PrintWriter pw = new PrintWriter(fos)) {
			// take each user in the map and write it to the file.
			for(User u: users.values()) {
				// print users email/name/password/premium or free
				pw.println(u.toFileString());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} // automatically close resources at end
	}

	//called when wanting to do a quick run
	public void makeFakeData() {
		// make a fake user
		//make fake parties and add to the sample host's list
		//invite the sample guest to those parties
		//then log in using the below sample credentials
		User g = new Guest("Sample Guest", "sampleguest", "guest");
		User h = new Host("Sample Host", "samplehost", "host");
		users.put(g.getEmail(), g);
		users.put(h.getEmail(), h);
		Guest guest = (Guest) g;
		Host host = (Host) h;
		Party p1 = new CelebrationParty("Birthday", "August 30, 2020", "123 Java St", "You are invited to come celebrate User's birthday!", host);
		Party p2 = new CasualParty("Get-Together", "August 20, 2020", "234 Python Pl", "You are invited to our get-together", host);
		Party p3 = new VirtualParty("Zoom Birthday Party", "September 2, 2020", "You are invited to virtually celebrate User's birthday!", host, "https://zoom/link.com");
		p1.addGuestToList(guest);
		p2.addGuestToList(guest);
		p3.addGuestToList(guest);
		Item i = new Item("Coca Cola", "drink");
		((CasualParty) p2).addItemToList(i, 2);
		host.addPartyToList(p1);
		host.addPartyToList(p2);
		host.addPartyToList(p3);
		signin();
	}

	public static void main(String[] args) {
		EviteSystem evite = new EviteSystem();
		evite.run();
		evite.writeUsersToFile("bin/users.txt");
	}
}
