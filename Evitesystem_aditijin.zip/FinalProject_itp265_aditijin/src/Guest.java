import java.util.ArrayList;

/**
 * Guest Class
 * Subclass of user, is the default type of user and is free
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public class Guest extends User {

	private ArrayList<Party> invitedParties; 

	public Guest(String name, String email, String password) {
		this(name, email, password, false);
	}

	public Guest(String name, String email, String password, boolean isPremium) {
		this(name, email, password, isPremium, new ArrayList<>());
	}

	public Guest(String name, String email, String password, boolean isPremium, ArrayList<Party> invitedParties) {
		super(name, email, password, isPremium);
		this.invitedParties = invitedParties;
	}

	public Guest(String name, String email, String password, ArrayList<Party> invitedParties) {
		this(name, email, password, false, invitedParties);
	}

	/**
	 * @return the invitedParties
	 */
	public ArrayList<Party> getInvitedParties() {
		return invitedParties;
	}

	/**
	 * @param invitedParties the invitedParties to set
	 */
	public void setInvitedParties(ArrayList<Party> invitedParties) {
		this.invitedParties = invitedParties;
	}


	public String InvitedPartiesToString() {
		String s = "Parties you are invited to:\n";

		if(invitedParties.size() == 0) {
			s += "EMPTY\n";
		}
		else {
			for(int i = 0; i < invitedParties.size(); i++) {
				s += "\n" + (i+1) + ".) " + invitedParties.get(i) + "\n";
			}
		}
		return s;
	}

	public void addParty(Party party) {
		invitedParties.add(party);
	}

}
