/**
 * Gift class
 * Defines a gift by its name, type, and gifter 
 *
 * @author Aditi Jindal
 * ITP 265, Summer 2020
 * Final Project
 * Email: aditijin@usc.edu
 *
 */
public class Gift {
	private String gifter;
	private String name;
	private String type;
	
	public Gift(String gifter, String name, String type) {
		this.gifter = gifter;
		this.name = name;
		this.type = type;
	}
	
	/**
	 * @return the gifter
	 */
	public String getGifter() {
		return gifter;
	}

	/**
	 * @param gifter the gifter to set
	 */
	public void setGifter(String gifter) {
		this.gifter = gifter;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}


	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}


	public String toString() {
		return gifter + " gifted " + name + " (" + type + ")";
	}
}
